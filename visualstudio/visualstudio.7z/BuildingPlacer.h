#pragma once
#include <BWAPI.h>
#include <vector>
#include <unordered_map>
#include "../visualstudio/BWEB/Source/BWEB.h"
#include <unordered_map>
#include <map>
#include "../visualstudio/BWEB/Source/BWEB.h"

#define PYLON_POWER_WIDTH 16
#define PYLON_POWER_HEIGHT 10

//Need to keep track of different blocks sizes somehow
//Large Blocks have atleast 2 more large placements
//Medium Blocks have 1 large placement or 1/2 medium placements.
//Small Blocks are anything otherwise.

struct BlockData {

	int Large_Placements = 0;
	int Medium_Placements = 0; 
	int Power_Placements = 0; //Blocks used to power other medium and large building locations, 2x2 blocks will use this as a counter.

	int Large_UsedPlacements = 0;
	int Medium_UsedPlacements = 0;
	int Power_UsedPlacements = 0;

	//BWEM Area a block is located in.
	const BWEM::Area* Block_AreaLocation; 
};

class BuildingPlacer
{
private:
	//Might not need these and just want to store the info in BlockData
	std::vector<std::vector<int>> poweredTiles;
	std::vector<BWEB::Block> largeBlocks;
	std::vector<BWEB::Block> mediumBlocks;
	std::vector<BWEB::Block> smallBlocks;


	std::map<BWAPI::TilePosition, BlockData> Block_Information;

	//Might need this to make getting blocks in Areas we own easier.
	std::unordered_set<const BWEM::Area *> AreasOccupied;

	//List of all the blocks from the areas we own.
	std::vector<BWEB::Block> ProtoBot_Blocks;

	//All the Areas the BWEM has and the blocks that are assigned to them. For the purpose of expanding our base we will only place in areas we own.
	//This should not apply to Walls, Proxy, and Cheeses.
	std::unordered_map<const BWEM::Area*, std::vector<BWEB::Block>> Area_Blocks;


	int mapWidth = 0;
	int mapHeight = 0;

public:
	int Used_LargeBuildingPlacements;
	int Used_MediumBuildingPlacements;

	BuildingPlacer();
	BWAPI::Position getPositionToBuild(BWAPI::UnitType);
	bool alreadyUsingTiles(BWAPI::TilePosition, int, int);
	bool checkPower(BWAPI::TilePosition, BWAPI::UnitType);
	void drawPoweredTiles();

	void onStart();
	void onUnitCreate(BWAPI::Unit);
	void onUnitComplete(BWAPI::Unit);
	void onUnitDestroy(BWAPI::Unit);
	void onUnitMorph(BWAPI::Unit);
	void onUnitDiscover(BWAPI::Unit);
};

