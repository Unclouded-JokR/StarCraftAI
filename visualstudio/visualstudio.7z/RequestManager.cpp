#include "RequestManager.h"

BWAPI::Unit RequestManager::requestUnit(BWAPI::Unit unit)
{
	return BWAPI::Unit();
}
